from django.apps import AppConfig


class PlaceorderConfig(AppConfig):
    name = 'placeorder'
